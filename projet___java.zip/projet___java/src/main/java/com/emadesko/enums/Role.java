package com.emadesko.enums;

public enum Role {
    Client,Boutiquier,Admin;
}
