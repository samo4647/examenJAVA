package com.emadesko.enums;

public enum RepositoryType {
    LIST , JPA , DATABASE
}
