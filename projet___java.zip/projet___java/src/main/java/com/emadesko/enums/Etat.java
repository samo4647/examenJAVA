package com.emadesko.enums;

public enum Etat {
    EnCours, Rejetée, Acceptée
}
