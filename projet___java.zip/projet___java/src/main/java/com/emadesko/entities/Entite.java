package com.emadesko.entities;

public class Entite {
    public void setId(int id){
    }
    public int getId(){
        return 0;
    }
    // public DetteMere getDetteMere() {
    //     return null;
    // }
    // public Article getArticle() {
    //     return null;
    // }
}
