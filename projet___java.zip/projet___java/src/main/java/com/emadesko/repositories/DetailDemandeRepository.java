package com.emadesko.repositories;

import com.emadesko.entities.DetailDemande;


public interface DetailDemandeRepository extends DetailMereRepository<DetailDemande>{
}